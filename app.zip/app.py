# Primeiro, vamos carregar o dataset e verificar suas primeiras linhas para entender as colunas disponíveis e a estrutura dos dados.

import pandas as pd


file_path = 'data/houses_Madrid.csv'
data = pd.read_csv(file_path)

# Mostrar as primeiras linhas do dataset para inspeção inicial
data.head()

data.columns.tolist()

# Selecionar colunas relevantes para o dashboard e modelagem
# Atualizar a lista de colunas com o nome correto para o preço
# Atualizar a lista de colunas com o nome correto para o preço
columns_to_keep = [
    'sq_mt_built', 'sq_mt_useful', 'n_rooms', 'n_bathrooms',
    'has_parking', 'buy_price'
]

# Filtrar o dataset com as colunas de interesse
filtered_data = data[columns_to_keep]

# Verificar valores ausentes
missing_values = filtered_data.isnull().sum()

# Exibir resumo dos valores ausentes e primeiras linhas do dataset filtrado
filtered_data.head(), missing_values




